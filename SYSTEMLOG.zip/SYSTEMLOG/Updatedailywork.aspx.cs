﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Updatedailywork : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bin();
            filedata();
        }
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from workfolder", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
    public void filedata()
    {
        if (Request.QueryString["sno"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from workfolder where sno='"+Request.QueryString["sno"].ToString()+"'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                TextBox1.Text = dr["folderid"].ToString();
                TextBox2.Text = dr["foldername"].ToString();
                TextBox6.Text = dr["employeename"].ToString();
                TextBox4.Text = dr["designation"].ToString();
                TextBox5.Text = dr["workdate"].ToString();
            }
        }
    }
    public void updatedata()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("update workfolder set folderid='"+TextBox1.Text+"',foldername='"+TextBox2.Text+"',employeename='"+ TextBox6.Text +"',designation='"+TextBox4.Text+"',workdate='"+TextBox5.Text+"' where sno='" + Request.QueryString["sno"].ToString() + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Updated Successfully')</script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        updatedata();
    }
    public void deletedata()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("delete from workfolder where id='" + Request.QueryString["id"].ToString() + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Deleted Successfully')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        deletedata();
    }


    
}
