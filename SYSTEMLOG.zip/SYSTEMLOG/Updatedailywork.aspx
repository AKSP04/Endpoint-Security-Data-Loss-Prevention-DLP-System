﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Updatedailywork.aspx.cs" Inherits="Updatedailywork" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Automatic System Logged At File Hacking Alert System</title>
<meta name="keywords" content="free css templates, free website templates, simple blue, light gray" />
<meta name="description" content="Simple Blue is a free CSS template from www.templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
    <style type="text/css">
        .style3
        {
            border: 2px ridge #2A90C1;
            width: 365px;
                height: 198px;
        }
        .style4
        {
            width: 154px;
        }
        .style5
        {
            width: 154px;
            height: 26px;
        }
        .style6
        {
            height: 26px;
        }
        .style7
        {
            width: 154px;
            height: 21px;
        }
        .style8
        {
            height: 21px;
        }
        </style>
        <script language="javascript" type="text/javascript">
    function filedata(sno)
    {
    location.href='Updatedailywork.aspx?sno='+sno;
    }
    </script>
        </head>
<body>
    <form id="form1" runat="server">
  <div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
    	<div id="site_title">
            <h1><a href="#">Welcome<span></span></a></h1>
        </div>
        
        <ul id="templatemo_menu">
            <li><a href="Default.aspx" ><span></span>Home</a></li>
            <li><a href="Viewemployee.aspx" ><span></span>Employee</a></li>
			<li><a href="adddailyworkfile.aspx" class="current" ><span></span>Send File</a></li>    
         <li><a href="Viewdevicedetails.aspx"><span></span>Device Details</a></li>  
            <li><a href="Default.aspx" ><span></span>Logout</a></li>  
        </ul>
        
        <div id="search_box">
       </div>
	</div> <!-- end of templatemo_site_title_bar -->        
       
</div> <!-- end of templatemo_site_title_bar_wrapper -->
<%--
<div id="templatemo_banner_wrapper_outter">
<div id="templatemo_banner_wrapper">
	
    <div id="templatemo_banner">
    
    <div id="templatemo_banner_slider">
    <!-- start of the slider -->
    
    <div id="one" class="contentslider">
            <div class="cs_wrapper">
                <div class="cs_slider">
                
                    <div class="cs_article">
                        <div class="cs_article_inner">
                             <div class="img_frame"><img src="images2.jpg" alt="Image Title 1" /></div>
                              <h2>Welcome</h2>
                              <p>Automatic System Logged At File Hacking Alert System</p>
                          
                        </div>                               
                    </div><!-- End cs_article -->
                    
                    <div class="cs_article">
                        <div class="cs_article_inner">
                            <div class="img_frame"><img src="images1.png" alt="Image Title 2" /></div>
                            <h2>Welcome</h2>
                            <p>Automatic System Logged At File Hacking Alert System</p>
                         
                        
                        </div>
                    </div><!-- End cs_article -->
                    
                    
                    
                </div><!-- End cs_slider -->
            </div><!-- End cs_wrapper -->
        </div><!-- End contentslider -->--%>
        
        <!-- Site JavaScript -->
        <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
        <script type="text/javascript">
            $(function() {
            $('#one').ContentSlider({
            width : '960px',
            height : '250px',
          	speed : 400,
            easing : 'easeOutSine'
            });
            });
        </script>
        <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
        <script src="js/chili/recipes.js" type="text/javascript"></script>
        <div class="cleaner">
    
    	<div class="cleaner"></div>
        </div>
  
  		<!-- end of the slider -->  
  
    
   	  </div> <!-- end of templatemo_popular_posts -->
    
    </div> <!-- end of templatemo_banner -->

</div> <!-- end of templatemo_banner_wrapper -->
</div> <!-- end of templatemo_banner_wrapper_outter -->

<div id="templatemo_content">
	
    <div id="twitter_section">
    	
        <p><span lang="en-us">Employee Daily Work Allotment</span></p>
     
    </div>
    
  
    <div class="cleaner_h60" align="justify">
  <table class="style3">
  <tr>
  <td class="style5">
      <asp:Label ID="Label1" runat="server" Text="Folder ID" Font-Bold="True" 
          Font-Size="13px" ForeColor="#6666FF"></asp:Label>
  </td>
  <td class="style6">
      <asp:TextBox ID="TextBox1" runat="server" Width="72px"></asp:TextBox>
  </td>
  </tr>
  <tr>
  <td class="style7">
      <asp:Label ID="Label2" runat="server" Text="Folder Name" Font-Bold="True" 
          Font-Size="13px" ForeColor="#6666FF"></asp:Label>
  </td>
  <td class="style8">
      <asp:TextBox ID="TextBox2" runat="server" Width="150px"></asp:TextBox>
  </td>
  </tr>
   <tr>
  <td class="style4">
      <asp:Label ID="Label3" runat="server" Text="Employee Name" Font-Bold="True" 
          Font-Size="13px" ForeColor="#6666FF"></asp:Label>
  </td>
  <td>
      <asp:TextBox ID="TextBox6" runat="server" Width="147px"></asp:TextBox>
  </td>
  </tr>
   <tr>
  <td class="style4">
      <asp:Label ID="Label4" runat="server" Text="Designation" Font-Bold="True" 
          Font-Italic="False" Font-Size="13px" ForeColor="#6666FF"></asp:Label>
  </td>
  <td>
      <asp:TextBox ID="TextBox4" runat="server" Width="148px"></asp:TextBox>
  </td>
  </tr>
   <tr>
  <td class="style4">
      <asp:Label ID="Label5" runat="server" Text="Work Alloted Date" Font-Bold="True" 
          Font-Size="13px" ForeColor="#6666FF"></asp:Label>
  </td>
  <td>
      <asp:TextBox ID="TextBox5" runat="server" Width="96px"></asp:TextBox>
  </td>
  </tr>
  <tr>
  <td class="style4">
      <asp:Button ID="Button1" runat="server" Text="Edit" Font-Bold="True" 
          Font-Size="13px" ForeColor="#6666FF" Width="91px" BackColor="White" 
          onclick="Button1_Click" />
  </td>
   <td>
      <asp:Button ID="Button2" runat="server" Text="Delete" Font-Bold="True" 
           Font-Size="13px" ForeColor="#6666FF" Width="85px" BackColor="White" 
           onclick="Button2_Click" />
  </td>
  </tr>
 
  </table>
  <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
       PageSize="3" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
            Height="198px" Font-Bold="True"  HorizontalAlign="Center" 
       CellPadding="4" CssClass="style2" ForeColor="#333333" GridLines="None" 
            style="width: 502px; position: absolute; left: 539px; top: 530px">
            <RowStyle HorizontalAlign="Center" BackColor="#EFF3FB"/>
                <Columns>
                   <asp:BoundField DataField="sno" HeaderText="Sno" />
                   <asp:BoundField DataField="folderid" HeaderText="Folder ID" />
                   <asp:BoundField DataField="foldername" HeaderText="Folder Name"/>
                   <asp:BoundField DataField="employeename" HeaderText="Employee Name"/>
               
                   <asp:BoundField DataField="designation" HeaderText="Designation"/>
                   <asp:BoundField DataField="workdate" HeaderText="Date"/>
                   <asp:BoundField DataField="status" HeaderText="Status"/>
                <asp:TemplateField>
                 <ItemTemplate>
                     <a href="javascript:filedata('<%#DataBinder.Eval(Container.DataItem,"sno")%>')">
                     View</a> &nbsp;&nbsp;
                 </ItemTemplate>
             </asp:TemplateField>
               </Columns>
            <FooterStyle BackColor="#507CD1" ForeColor="White" Font-Bold="True" />
            <PagerStyle ForeColor="White" HorizontalAlign="Center" BackColor="#2461BF" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <EditRowStyle BackColor="#2461BF" />
            <AlternatingRowStyle BackColor="White" />
 </asp:GridView>    
  
  </div>
    
    
</div> <!-- end of templatemo_content -->
 
<br />

<br />

<br />
<br />
<br />

<br />

<br />
<br />
<div id="templatemo_footer_wrapper">
<div id="templatemo_footer">

   
    <center>
        Copyright <a href="#">All Rights Reserved</a> 
       </center>
    

</div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->

    </form>
</body>
</html>
