﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net.Mail;
public partial class Viewdevicedetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            bin();
        }
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from devicedetails ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }


    public void sendmail()
    {
        if (Request.QueryString["employeename"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from empreg where employeename='" + Request.QueryString["employeename"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                
                Session["uemailid"] = dr["emailid"].ToString();
                
                Class1 getcon1 = new Class1();
                SqlConnection con1 = getcon1.connect();
                SqlCommand cmd1 = new SqlCommand("update empreg set status='deactive' where employeename='" + Request.QueryString["employeename"].ToString() + "'", con1);
                cmd1.ExecuteNonQuery();
                MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["uemailid"].ToString()));
                msg.Subject = "Your Account Was Blocked Due To Some Pendrive Access Meet with Hr Team.";
                msg.IsBodyHtml = true;
                msg.Body = "Username: " + Request.QueryString["employeename"];
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "noreply@12345");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
                ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Login is Activated Successfully and Send Mail!!!');</script>");
                bin();
            }
        }
    }
}
