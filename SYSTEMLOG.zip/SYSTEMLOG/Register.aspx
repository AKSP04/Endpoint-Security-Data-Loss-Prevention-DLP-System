﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Register.aspx.cs" Inherits="Register" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Automatic System Logged At File Hacking Alert System</title>
<meta name="keywords" content="free css templates, free website templates, simple blue, light gray" />
<meta name="description" content="Simple Blue is a free CSS template from www.templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
    <style type="text/css">
        .style3
        {
            width: 336px;
            border-style: ridge;
            border-width: 2px;
        }
        </style>
</head>
<body>
    <form id="form1" runat="server">
   <div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
    	<div id="site_title">
            <h1><a href="#">Welcome<span></span></a></h1>
        </div>
        
        <ul id="templatemo_menu">
            <li><a href="Default.aspx" ><span></span>Home</a></li>
            <li><a href="Admin.aspx"><span></span>Admin</a></li>
			<li><a href="Employee.aspx"><span></span>Employee</a></li>    
         	<li><a href="Register.aspx" class="current"><span></span>Register</a></li>     
        </ul>
        <div id="search_box">
           
       </div>
       
	</div> <!-- end of templatemo_site_title_bar -->        
       
</div> <!-- end of templatemo_site_title_bar_wrapper -->

<%--<div id="templatemo_banner_wrapper_outter">
<div id="templatemo_banner_wrapper">
	
    <div id="templatemo_banner">
    
    <div id="templatemo_banner_slider">
    <!-- start of the slider -->
    
    <div id="one" class="contentslider">
            <div class="cs_wrapper">
                <div class="cs_slider">
                
                    <div class="cs_article">
                        <div class="cs_article_inner">
                             <div class="img_frame"><img src="images2.jpg" alt="Image Title 1" /></div>
                              <h2>Welcome</h2>
                              <p>Automatic System Logged At File Hacking Alert System</p>
                          
                        </div>                               
                    </div><!-- End cs_article -->
                    
                    <div class="cs_article">
                        <div class="cs_article_inner">
                            <div class="img_frame"><img src="images1.png" alt="Image Title 2" /></div>
                            <h2>Welcome</h2>
                            <p>Automatic System Logged At File Hacking Alert System</p>
                         
                        
                        </div>
                    </div><!-- End cs_article -->
                    
                    
                    
                </div><!-- End cs_slider -->
            </div><!-- End cs_wrapper -->
        </div><!-- End contentslider -->--%>
        
        <!-- Site JavaScript -->
        <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
        <script type="text/javascript">
            $(function() {
            $('#one').ContentSlider({
            width : '960px',
            height : '250px',
          	speed : 400,
            easing : 'easeOutSine'
            });
            });
        </script>
        <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
        <script src="js/chili/recipes.js" type="text/javascript"></script>
        <div class="cleaner"></div>
  
  		<!-- end of the slider -->  
  
    
   	  </div> <!-- end of templatemo_popular_posts -->
    
    </div> <!-- end of templatemo_banner -->

</div> <!-- end of templatemo_banner_wrapper -->
</div> <!-- end of templatemo_banner_wrapper_outter -->

<div id="templatemo_content">
	
    <div id="twitter_section">
    	
        <p><span lang="en-us">Registration Form</span></p>
     
    </div>
    
  
    <div class="cleaner_h60" align="justify">
    
    <table class="style3">
    <tr>
    <td>
        <asp:Label ID="Label1" runat="server" Text="Employee Name" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox1" runat="server" Width="170px"></asp:TextBox>
   </td>
    </tr>
     <tr>
    <td>
        <asp:Label ID="Label2" runat="server" Text="Password" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox2" runat="server" Width="168px" TextMode="Password"></asp:TextBox>
   </td>
    </tr>
     <tr>
    <td>
        <asp:Label ID="Label3" runat="server" Text="Gender" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:RadioButtonList ID="RadioButtonList1" runat="server">
       <asp:ListItem Text="Male"></asp:ListItem>
        <asp:ListItem Text="Female"></asp:ListItem>
       </asp:RadioButtonList>
   </td>
    </tr>
      <tr>
    <td>
        <asp:Label ID="Label4" runat="server" Text="Age" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox4" runat="server" Width="80px"></asp:TextBox>
   </td>
    </tr>
     <tr>
    <td>
        <asp:Label ID="Label5" runat="server" Text="Qualification" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>
   </td>
    </tr>
    <tr>
    <td>
        <asp:Label ID="Label6" runat="server" Text="Designation" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox5" runat="server"></asp:TextBox>
   </td>
    </tr>
    <tr>
    <td>
        <asp:Label ID="Label7" runat="server" Text="Address" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox6" runat="server" Height="30px" Width="162px"></asp:TextBox>
   </td>
    </tr>
      <tr>
    <td>
        <asp:Label ID="Label8" runat="server" Text="Emailid" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox7" runat="server" Height="22px" Width="162px"></asp:TextBox>
   </td>
    </tr>
      <tr>
    <td>
        <asp:Label ID="Label9" runat="server" Text="Phoneno" Font-Bold="True" 
            Font-Size="14px" ForeColor="#9999FF"></asp:Label>
    </td>
   <td>
       <asp:TextBox ID="TextBox8" runat="server" Width="162px"></asp:TextBox>
   </td>
    </tr>
     <tr>
    <td>
        <asp:Button ID="Button1" runat="server" Text="Submit" Font-Bold="True" 
            Font-Size="14px" ForeColor="#6666FF" onclick="Button1_Click" Width="74px" />
    </td>
    </tr>
    </table>
 
     </div>
    
    <div class="section_w940">
    
    	<div class="section_w450 margin_r_40">
        
          <div class="button_01"></div>
            
            
            <div class="cleaner_h40"></div>
            
            <div class="cleaner"></div>
         
            
        </div>
        
        <div class="section_w450">
        	
        </div>
    
    	<div class="cleaner"></div>
    </div>
    
    
    <div class="cleaner"></div>
</div> <!-- end of templatemo_content -->
 
   <br />
    <br />
     <br />
    <br />
     <br />
    <br />   <span lang="en-us">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>   <br />
    <br />
      <br />
    <br />
     <br />
    <br />
<div id="templatemo_footer_wrapper">
<div id="templatemo_footer">

   
    <center>
        Copyright <a href="#">All Rights Reserved</a> 
       </center>
    

</div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->

    </form>
</body>
</html>
