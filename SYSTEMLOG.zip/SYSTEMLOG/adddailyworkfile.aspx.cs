﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class adddailyworkfile : System.Web.UI.Page
{
    SqlDataAdapter dadapter;
    DataSet dset;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            string sql = "select distinct(employeename) from empreg";
            if (!IsPostBack)
            {
                dadapter = new SqlDataAdapter(sql, con);
                dset = new DataSet();
                dadapter.Fill(dset);
                DropDownList1.DataSource = dset.Tables[0];
                DropDownList1.DataTextField = "employeename";
                DropDownList1.DataValueField = "employeename";
                DropDownList1.DataBind();
            }
            updatedisplay();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string ss = FileUpload1.PostedFile.FileName;
        //string SaveLocation = Server.MapPath(Session["uid"].ToString()) + "\\" + fn;
        string ff = Server.MapPath(DropDownList1.SelectedItem.Text)+"\\" + ss;
       // string ff = Server.MapPath("E:\\theja\\") + ss;
        FileUpload1.SaveAs(ff);
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into workfolder values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','Send','"+ss+"')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Work Details Forward Successfully')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Updatedailywork.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Updatedailywork.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewdailywork.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        updatedisplay();
    }
    public void updatedisplay()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from empreg where employeename='" + DropDownList1.SelectedValue + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            TextBox4.Text = dr["designation"].ToString();
        }
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}
