﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="EmployeeHome.aspx.cs" Inherits="EmployeeHome" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Automatic System Logged At File Hacking Alert System</title>
<meta name="keywords" content="free css templates, free website templates, simple blue, light gray" />
<meta name="description" content="Simple Blue is a free CSS template from www.templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
    <style type="text/css">
        .style2
        {
            width: 397px;
            border: 2px ridge #2A90C1;
            height: 101px;
        }
        </style>
</head>
<body>
    <form id="form1" runat="server">
    <div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
    	<div id="site_title">
            <h1><a href="#">Welcome<span></span></a></h1>
        </div>
        
        <ul id="templatemo_menu">
                     <li><a href="EmployeeHome.aspx" class="current"><span></span>Home</a></li>
            <li><a href="Viewworkdetails.aspx"><span></span>Work Details</a></li>
			<li><a href="Uploadfile.aspx"><span></span>Upload File</a></li>    
            <li><a href="viewprofile.aspx"><span></span>Profile Details</a></li>  
            <li><a href="Default.aspx"><span></span>Logout</a></li>  
        </ul>
        
        <div id="search_box">
           
       </div>
       
	</div> <!-- end of templatemo_site_title_bar -->        
       
</div> <!-- end of templatemo_site_title_bar_wrapper -->

<div id="templatemo_banner_wrapper_outter">
<div id="templatemo_banner_wrapper">
	
    <div id="templatemo_banner">
    
    <div id="templatemo_banner_slider">
    <!-- start of the slider -->
    
    <div id="one" class="contentslider">
            <div class="cs_wrapper">
                <div class="cs_slider">
                
                    <div class="cs_article">
                       <div class="cs_article_inner">
                             <div class="img_frame"><img src="images2.jpg" alt="Image Title 1" /></div>
                              <h2>Welcome</h2>
                              <p>Automatic System Logged At File Hacking Alert System</p>
                          
                        </div>                               
                    </div><!-- End cs_article -->
                    
                    <div class="cs_article">
                        <div class="cs_article_inner">
                            <div class="img_frame"><img src="images1.png" alt="Image Title 2" /></div>
                            <h2>Welcome</h2>
                            <p>Automatic System Logged At File Hacking Alert System</p>
                         
                        
                        </div>
                    </div><!-- End cs_article -->
                    
                    
                    
                </div><!-- End cs_slider -->
            </div><!-- End cs_wrapper -->
        </div><!-- End contentslider -->
        --%>
        <!-- Site JavaScript -->
        <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
        <script type="text/javascript">
            $(function() {
            $('#one').ContentSlider({
            width : '960px',
            height : '250px',
          	speed : 400,
            easing : 'easeOutSine'
            });
            });
        </script>
        <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
        <script src="js/chili/recipes.js" type="text/javascript"></script>
        <div class="cleaner"></div>
  
  		<!-- end of the slider -->  
  
    
   	  </div> <!-- end of templatemo_popular_posts -->
    
    </div> <!-- end of templatemo_banner -->

</div> <!-- end of templatemo_banner_wrapper -->
</div> <!-- end of templatemo_banner_wrapper_outter -->

<div id="templatemo_content">
	
    <div id="twitter_section">
    	
        <p><span lang="en-us">Automatic System Logged At File Hacking Alert System</span></p>
     
    </div>
    
  
    <div class="cleaner_h60" align="justify">
    <p style="font-size:12px;">
    Automatic System Logged At File Hacking Alert System project main aim is to give alert message if third party is trying to insert the device like pendrive or harddisk into their laptop or desktop.To copy the files from the laptop or desktop.This type of security will help to the organization to protect the files or folders from the unauthorized user.Two persons involved in this project are admin and employee.Admin will maintain the record of the employees and maintain all the work allotment files of the employees.Employees are once finish the work allotment sheet means that will forward to the admin.Suppose the employee or any other third party accessing files means then automatically maill transfer to the admin.
  </p> 
  
 <div>


<table>
<tr>
<td style="width: 183px">
<asp:Label ID="Label1" runat="server" Visible="false">Available Free Space:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labAvailableFreeSpace" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label2" runat="server"  Visible="false">Drive Format:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labFormat" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label3" runat="server"  Visible="false">Drive Type:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labType" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label4" runat="server"  Visible="false">Is Ready:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labReady" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label5" runat="server"  Visible="false">Name:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labName" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label6" runat="server" Visible="false">Root Directory:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labRootDirectory" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label7" runat="server"  Visible="false">ToString() Value:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labValue" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label8" runat="server" Visible="false">Total Free Space:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labFreeSpace" runat="server"  Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label9" runat="server"  Visible="false">Total Size:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labTotalSize" runat="server"  Visible="false"></asp:Label></td>
</tr>

</table>
</fieldset></div> 
     
  </div>
  </div>
    
    <div class="section_w940">
    
    	<div class="section_w450 margin_r_40">
        
          <div class="button_01"></div>
            
            
            <div class="cleaner_h40"></div>
            
            <div class="cleaner"></div>
         
            
        </div>
        
        <div class="section_w450">
        	
        </div>
    
    	<div class="cleaner"></div>
    </div>
    
    
    <div class="cleaner"></div>
</div> <!-- end of templatemo_content -->
 

<div id="templatemo_footer_wrapper">
<div id="templatemo_footer">

   
    <center>
        Copyright <a href="#">All Rights Reserved</a> 
       </center>
    

</div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->

    </form>
</body>
</html>
