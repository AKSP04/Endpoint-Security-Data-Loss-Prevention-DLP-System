﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Uploadfile.aspx.cs" Inherits="Uploadfile" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Secured File Alert Monitoring System</title>
<meta name="keywords" content="free css templates, free website templates, simple blue, light gray" />
<meta name="description" content="Simple Blue is a free CSS template from www.templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
   
          <style type="text/css">
              .style1
              {
                  width: 364px;
                  height: 210px;
                  border: 2px ridge #2A90C1;
                  position: absolute;
                  left: 393px;
                  top: 171px;
              }
              .style2
              {
                  width: 107px;
              }
          </style>
 
</head>
<body>
    <form id="form1" runat="server">
      <div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
    	<div id="site_title">
            <h1><a href="#">Welcome<span></span></a></h1>
        </div>
        
        <ul id="templatemo_menu">
            <li><a href="EmployeeHome.aspx" class="current"><span></span>Home</a></li>
            <li><a href="Viewworkdetails.aspx"><span></span>Work Details</a></li>
			<li><a href="Uploadfile.aspx" class="current"><span></span>Upload File</a></li>    
            <li><a href="viewprofile.aspx"><span></span>Profile Details</a></li> 
          
            <li><a href="Default.aspx"><span></span>Logout</a></li>  
        </ul>
        
        <div id="search_box">
           
       </div>
       
	</div> <!-- end of templatemo_site_title_bar -->        
       
</div> <!-- end of templatemo_site_title_bar_wrapper -->

<%--<div id="templatemo_banner_wrapper_outter">
<div id="templatemo_banner_wrapper">
	
    <div id="templatemo_banner">
    
    <div id="templatemo_banner_slider">
    <!-- start of the slider -->
    
    <div id="one" class="contentslider">
            <div class="cs_wrapper">
                <div class="cs_slider">
                
                    <div class="cs_article">
                        <div class="cs_article_inner">
                             <div class="img_frame"><img src="images2.jpg" alt="Image Title 1" /></div>
                              <h2>Welcome</h2>
                              <p>Automatic System Logged At File Hacking Alert System</p>
                          
                        </div>                               
                    </div><!-- End cs_article -->
                    
                    <div class="cs_article">
                        <div class="cs_article_inner">
                            <div class="img_frame"><img src="images1.png" alt="Image Title 2" /></div>
                            <h2>Welcome</h2>
                            <p>Automatic System Logged At File Hacking Alert System</p>
                         
                        
                        </div>
                    </div><!-- End cs_article -->
                    
                    
                    
                </div><!-- End cs_slider -->
            </div><!-- End cs_wrapper -->
        </div><!-- End contentslider -->--%>
        
        <!-- Site JavaScript -->
        <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
        <script type="text/javascript">
            $(function() {
            $('#one').ContentSlider({
            width : '960px',
            height : '250px',
          	speed : 400,
            easing : 'easeOutSine'
            });
            });
        </script>
        <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
        <script src="js/chili/recipes.js" type="text/javascript"></script>
        <div class="cleaner"></div>
  
  		<!-- end of the slider -->  
  
    
   	  </div> <!-- end of templatemo_popular_posts -->
    
    </div> <!-- end of templatemo_banner -->

</div> <!-- end of templatemo_banner_wrapper -->
</div> <!-- end of templatemo_banner_wrapper_outter -->

<div id="templatemo_content">
	
    <div id="twitter_section">
    	
        <p><span lang="en-us">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;File Details</span>&nbsp;</p>
     
    </div>
    
  
    <div class="cleaner_h60" align="justify">
<table class="style1">
<tr>
<td class="style2">
    <asp:Label ID="Label1" runat="server" Text="Folder ID" Font-Bold="True" 
        Font-Size="13px" ForeColor="#9999FF"></asp:Label>
</td>
<td>
    <asp:DropDownList ID="DropDownList1" runat="server" 
        onselectedindexchanged="DropDownList1_SelectedIndexChanged">
    </asp:DropDownList>
</td>
</tr>
<tr>
<td class="style2">
    <asp:Label ID="Label2" runat="server" Text="Folder Name" Font-Bold="True" 
        Font-Size="13px" ForeColor="#9999FF"></asp:Label>
</td>
<td>
    <asp:TextBox ID="TextBox2" runat="server" Height="28px" Width="212px"></asp:TextBox>
</td>
</tr>
<tr>
<td class="style2">
    <asp:Label ID="Label3" runat="server" Text="File Name" Font-Bold="True" 
        Font-Size="13px" ForeColor="#9999FF"></asp:Label>
</td>
<td>
    <asp:TextBox ID="TextBox3" runat="server" Height="29px" Width="213px"></asp:TextBox>
</td>
</tr>
<tr>
<td class="style2">
    <asp:Label ID="Label4" runat="server" Text="Upload File" Font-Bold="True" 
        Font-Size="13px" ForeColor="#9999FF"></asp:Label>
</td>
<td>
    <asp:FileUpload ID="FileUpload1" runat="server" />
</td>
</tr>
<tr>
<td class="style2">
    <asp:Button ID="Button1" runat="server" Text="Save" BackColor="White" 
        ForeColor="#6666FF" onclick="Button1_Click" Width="75px" />
</td>
<td>
    <asp:Button ID="Button2" runat="server" Text="Edit" BackColor="White" 
        ForeColor="#6666FF" onclick="Button2_Click" Width="75px" />
</td>
</tr>
<tr>
<td class="style2">
    <asp:Button ID="Button3" runat="server" Text="Delete" BackColor="White" 
        ForeColor="#6666FF" onclick="Button3_Click" Width="76px" />
</td>
<td>
    <asp:Button ID="Button4" runat="server" Text="View" BackColor="White" 
        ForeColor="#6666FF" onclick="Button4_Click" Width="74px" />
</td>
</tr>
</table>
<table>
<tr>
<td style="width: 183px">
<asp:Label ID="Label5" runat="server" Visible="false">Available Free Space:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labAvailableFreeSpace" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px"> 
<asp:Label ID="Label6" runat="server" Visible="false">Drive Format:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labFormat" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label7" runat="server" Visible="false">Drive Type:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labType" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label8" runat="server" Visible="false">Is Ready:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labReady" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label9" runat="server" Visible="false">Name:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labName" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label10" runat="server" Visible="false">Root Directory:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labRootDirectory" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label11" runat="server" Visible="false">ToString() Value:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labValue" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label12" runat="server" Visible="false">Total Free Space:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labFreeSpace" runat="server" Visible="false"></asp:Label></td>
</tr>
<tr>
<td style="width: 183px">
<asp:Label ID="Label13" runat="server" Visible="false">Total Size:</asp:Label></td>
<td style="width: 283px">
<asp:Label ID="labTotalSize" runat="server" Visible="false"></asp:Label></td>
</tr>

</table>
    </div>
    
</div> <!-- end of templatemo_content -->
  <br />
    <br />
   
   <br />
    <br />
         <span lang="en-us">t&gt;     <br />
         <span lang="en-us">t</span><br />
    <br />
   
   <br />
    <br />

<div id="templatemo_footer_wrapper">
<div id="templatemo_footer">

   
    <center>
        Copyright <a href="#">All Rights Reserved</a> 
       </center>
    

</div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->

    </form>
</body>
</html>
