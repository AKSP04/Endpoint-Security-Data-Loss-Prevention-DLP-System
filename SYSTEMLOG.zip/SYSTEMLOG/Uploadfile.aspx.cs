﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Diagnostics;
public partial class Uploadfile : System.Web.UI.Page
{
    SqlDataAdapter dadapter;
    DataSet dset;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            string sql = "select * from workfolder";
            if (!IsPostBack)
            {
                dadapter = new SqlDataAdapter(sql, con);
                dset = new DataSet();
                dadapter.Fill(dset);
                DropDownList1.DataSource = dset.Tables[0];
                DropDownList1.DataTextField = "folderid";
                DropDownList1.DataValueField = "folderid";
                DropDownList1.DataBind();
            }
            DriveInfo[] di = DriveInfo.GetDrives();
            foreach (DriveInfo item in di)
            {
                string s = item.DriveType.ToString();
                if (s == "Removable")
                {
                    labAvailableFreeSpace.Text = item.AvailableFreeSpace.ToString();
                    labFormat.Text = item.DriveFormat.ToString();
                    labType.Text = item.DriveType.ToString();
                    labReady.Text = item.IsReady.ToString();
                    labName.Text = item.Name.ToString();
                    labRootDirectory.Text = item.RootDirectory.ToString();
                    labValue.Text = item.ToString();
                    labFreeSpace.Text = item.TotalFreeSpace.ToString();
                    labTotalSize.Text = item.TotalSize.ToString();
                    mailsend();
                    sendsms();
                    adddevice();
                    string a = "Sleep";
                    DoOperation(a);
                }

            }

            updatedisplay();
     
        }
    }
    private void DoOperation(string oparation)
    {
        string filename = string.Empty;
        string arguments = string.Empty;

        switch (oparation)
        {
            case "Shut Down":
                filename = "shutdown.exe";
                arguments = "-s";
                break;

            case "Restart":

                filename = "shutdown.exe";
                arguments = "-r";
                break;

            case "Logoff":

                filename = "shutdown.exe";
                arguments = "-l";
                break;

            case "Lock":

                filename = "Rundll32.exe";
                arguments = "User32.dll, LockWorkStation";
                break;
            case "Hibernation":

                filename = @"%windir%\system32\rundll32.exe";
                arguments = "PowrProf.dll, SetSuspendState";
                break;
            case "Sleep":

                filename = "Rundll32.exe";
                arguments = "powrprof.dll, SetSuspendState 0,1,0";
                break;
        }
        ProcessStartInfo startinfo = new ProcessStartInfo(filename, arguments);
        Process.Start(startinfo);
        //this.Close();

    }
    public void sendsms()
    {
        WebClient client = new WebClient();
        string strmsg = "Employeename" + Session["employeename"].ToString() + "Driver Name" + labName.Text + "Drive Type" + labType.Text;
        string baseurl = "http://sms.f9cs.com/sendsms.jsp?user=f9demo&password=demo1234&mobiles=" + 9994420787 + "&senderid=FINECS&sms='" + strmsg + "'";
        Stream data = client.OpenRead(baseurl);
        StreamReader reader = new StreamReader(data);
        string s = reader.ReadToEnd();
        data.Close();
        reader.Close();
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('SMS Send Successfully');</script>");
    }
    public void mailsend()
    {
        MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress("noreplymailing22@gmail.com"));
        msg.Subject = "New Driver is Accessed inside employee laptop!!!Pls check it";
        msg.IsBodyHtml = true;
        msg.Body = "Employee Name" + Session["employeename"].ToString() + "Driver Name" + labName.Text + "Drive Type" + labType.Text;
        //  msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, aa));
        System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "noreply@12345");
        SmtpClient smclient = new SmtpClient();
        smclient.EnableSsl = true;
        smclient.UseDefaultCredentials = false;
        smclient.Credentials = nwcred;
        smclient.Host = "smtp.gmail.com";
        smclient.Port = 587;
        smclient.Send(msg);
        Response.Write("<script>alert('Mail Sent Successfully')</script>");
    }
    public void adddevice()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into devicedetails values('" + Session["employeename"].ToString() + "','" + labFormat.Text + "','" + labType.Text + "','" + labName.Text + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "')", con);
        cmd.ExecuteNonQuery();
        //   Response.Write("<script>alert('Device Details Sav')</script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String aa = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
        String aa1 = Server.MapPath("work") + "\\" + aa;
        FileUpload1.PostedFile.SaveAs(aa1);
        int b = Convert.ToInt32(FileUpload1.PostedFile.ContentLength);
        String b1 = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName);
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into filedetails values('" + DropDownList1.SelectedValue + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + aa + "','"+b1+"','"+b.ToString()+"','"+DateTime.Now.ToString("dd/MM/yyyy")+"','Finished','"+Session["employeename"].ToString()+"')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('File Details Saved Successfully')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Updateuploadfile.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Updateuploadfile.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("viewuploadfile.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        updatedisplay();
    }
    public void updatedisplay()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from workfolder where folderid='" + DropDownList1.SelectedValue + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            TextBox2.Text = dr["foldername"].ToString();
        }
    }
}
