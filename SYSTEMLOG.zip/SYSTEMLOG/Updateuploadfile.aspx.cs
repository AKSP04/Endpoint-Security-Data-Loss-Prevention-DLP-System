﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Updateuploadfile : System.Web.UI.Page
{
    SqlDataAdapter dadapter;
    DataSet dset;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bin();
            filedata();
      
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            string sql = "select * from workfolder";
            if (!IsPostBack)
            {
                dadapter = new SqlDataAdapter(sql, con);
                dset = new DataSet();
                dadapter.Fill(dset);
                DropDownList1.DataSource = dset.Tables[0];
                DropDownList1.DataTextField = "folderid";
                DropDownList1.DataValueField = "folderid";
                DropDownList1.DataBind();
            }
            updatedisplay();
        }
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from filedetails where empname='" + Session["employeename"].ToString() + "' and status='Finished'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
    public void filedata()
    {
        if (Request.QueryString["id"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from filedetails where id='" + Request.QueryString["id"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {   
                TextBox2.Text = dr["foldername"].ToString();
                TextBox3.Text = dr["filename"].ToString();
            }
        }
    }
    public void updatedata()
    {
        String aa = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
        String aa1 = Server.MapPath("work") + "\\" + aa;
        FileUpload1.PostedFile.SaveAs(aa1);
        int b = Convert.ToInt32(FileUpload1.PostedFile.ContentLength);
        String b1 = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName);
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("update filedetails set folderid='" + DropDownList1.SelectedValue + "',foldername='" + TextBox2.Text + "',filename='" + TextBox3.Text + "',filepath='" + aa + "',fileext='" + b1 + "',filesize='"+b.ToString()+"',workdate='"+DateTime.Now.ToString("dd/MM/yyyy")+"',status='Forward',empname='"+Session["employeename"].ToString()+"' where id='" + Request.QueryString["id"].ToString() + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Updated Successfully')</script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        updatedata();
    }
    public void deletedata()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("delete from filedetails where id='" + Request.QueryString["id"].ToString() + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Deleted Successfully')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        deletedata();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        updatedisplay();
    }
    public void updatedisplay()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from workfolder where folderid='" + DropDownList1.SelectedValue + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            TextBox2.Text = dr["foldername"].ToString();
        }
    }
}
