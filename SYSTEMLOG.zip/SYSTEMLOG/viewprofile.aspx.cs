﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Diagnostics;
public partial class viewprofile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bin();
            DriveInfo[] di = DriveInfo.GetDrives();
            foreach (DriveInfo item in di)
            {
                string s = item.DriveType.ToString();
                if (s == "Removable")
                {
                    labAvailableFreeSpace.Text = item.AvailableFreeSpace.ToString();
                    labFormat.Text = item.DriveFormat.ToString();
                    labType.Text = item.DriveType.ToString();
                    labReady.Text = item.IsReady.ToString();
                    labName.Text = item.Name.ToString();
                    labRootDirectory.Text = item.RootDirectory.ToString();
                    labValue.Text = item.ToString();
                    labFreeSpace.Text = item.TotalFreeSpace.ToString();
                    labTotalSize.Text = item.TotalSize.ToString();
                    mailsend();
                    sendsms();
                    adddevice();
                    string a = "Sleep";
                    DoOperation(a);
                }

            }
        }
    }
    private void DoOperation(string oparation)
    {
        string filename = string.Empty;
        string arguments = string.Empty;

        switch (oparation)
        {
            case "Shut Down":
                filename = "shutdown.exe";
                arguments = "-s";
                break;

            case "Restart":

                filename = "shutdown.exe";
                arguments = "-r";
                break;

            case "Logoff":

                filename = "shutdown.exe";
                arguments = "-l";
                break;

            case "Lock":

                filename = "Rundll32.exe";
                arguments = "User32.dll, LockWorkStation";
                break;
            case "Hibernation":

                filename = @"%windir%\system32\rundll32.exe";
                arguments = "PowrProf.dll, SetSuspendState";
                break;
            case "Sleep":

                filename = "Rundll32.exe";
                arguments = "powrprof.dll, SetSuspendState 0,1,0";
                break;
        }
        ProcessStartInfo startinfo = new ProcessStartInfo(filename, arguments);
        Process.Start(startinfo);
        //this.Close();

    }
    public void sendsms()
    {
        WebClient client = new WebClient();
        string strmsg = "Employeename" + Session["employeename"].ToString() + "Driver Name" + labName.Text + "Drive Type" + labType.Text;
        string baseurl = "http://sms.f9cs.com/sendsms.jsp?user=f9demo&password=demo1234&mobiles=" + 9994420787 + "&senderid=FINECS&sms='" + strmsg + "'";
        Stream data = client.OpenRead(baseurl);
        StreamReader reader = new StreamReader(data);
        string s = reader.ReadToEnd();
        data.Close();
        reader.Close();
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('SMS Send Successfully');</script>");
    }
    public void mailsend()
    {
        MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress("noreplymailing22@gmail.com"));
        msg.Subject = "New Driver is Accessed inside employee laptop!!!Pls check it";
        msg.IsBodyHtml = true;
        msg.Body = "Employee Name" + Session["employeename"].ToString() + "Driver Name" + labName.Text + "Drive Type" + labType.Text;
        //  msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, aa));
        System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "noreply@12345");
        SmtpClient smclient = new SmtpClient();
        smclient.EnableSsl = true;
        smclient.UseDefaultCredentials = false;
        smclient.Credentials = nwcred;
        smclient.Host = "smtp.gmail.com";
        smclient.Port = 587;
        smclient.Send(msg);
        Response.Write("<script>alert('Mail Sent Successfully')</script>");
    }
    public void adddevice()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into devicedetails values('" + Session["employeename"].ToString() + "','" + labFormat.Text + "','" + labType.Text + "','" + labName.Text + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "')", con);
        cmd.ExecuteNonQuery();
        //   Response.Write("<script>alert('Device Details Sav')</script>");
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from empreg where employeename='"+Session["employeename"].ToString()+"'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
}
