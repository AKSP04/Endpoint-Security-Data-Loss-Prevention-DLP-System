﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string appPath = Request.PhysicalApplicationPath.ToString();

        //DirectoryInfo newDirectory = new DirectoryInfo(appPath + Session["uid"].ToString());

        //string appPath = @"E:\";

        DirectoryInfo newDirectory = new DirectoryInfo(appPath + TextBox1.Text);

        newDirectory.Create();
               
        Class1 getcon = new Class1();
        SqlConnection con = new SqlConnection();
        con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into empreg values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+RadioButtonList1.SelectedValue+"','"+TextBox4.Text+"','"+TextBox3.Text+"','"+TextBox5.Text+"','"+TextBox6.Text+"','"+TextBox7.Text+"','"+TextBox8.Text+"','Accept')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Employee Register Saved Successfully')</script>");
    }
}
