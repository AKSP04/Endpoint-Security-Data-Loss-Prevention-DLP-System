﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
public partial class devicedetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DriveInfo[] di = DriveInfo.GetDrives();
            foreach (DriveInfo item in di)
            {
                string s = item.DriveType.ToString();
                if (s == "Removable")
                {
                    labAvailableFreeSpace.Text = item.AvailableFreeSpace.ToString();
                    labFormat.Text = item.DriveFormat.ToString();
                    labType.Text = item.DriveType.ToString();
                    labReady.Text = item.IsReady.ToString();
                    labName.Text = item.Name.ToString();
                    labRootDirectory.Text = item.RootDirectory.ToString();
                    labValue.Text = item.ToString();
                    labFreeSpace.Text = item.TotalFreeSpace.ToString();
                    labTotalSize.Text = item.TotalSize.ToString();

                    mailsend();
                    adddevice();
                }

            }
        }
    }
 
    public void mailsend()
    {
        MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress("noreplymailing22@gmail.com"));
        msg.Subject = "New Driver is Accessed inside employee laptop!!!Pls check it";
        msg.IsBodyHtml = true;
        msg.Body = "Employee Name"+Session["employeename"].ToString()+"Driver Name" + labName.Text + "Drive Type" + labType.Text;
        //  msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, aa));
        System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "noreply@12345");
        SmtpClient smclient = new SmtpClient();
        smclient.EnableSsl = true;
        smclient.UseDefaultCredentials = false;
        smclient.Credentials = nwcred;
        smclient.Host = "smtp.gmail.com";
        smclient.Port = 587;
        smclient.Send(msg);
        Response.Write("<script>alert('Mail Sent Successfully')</script>");
    }
    public void adddevice()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into devicedetails values('" + Session["employeename"].ToString() + "','" + labFormat.Text + "','" + labType.Text + "','" + labName.Text + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "')", con);
        cmd.ExecuteNonQuery();
     //   Response.Write("<script>alert('Device Details Sav')</script>");
    }
}
