﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="completedfiles.aspx.cs" Inherits="completedfiles" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Automatic System Logged At File Hacking Alert System</title>
<meta name="keywords" content="free css templates, free website templates, simple blue, light gray" />
<meta name="description" content="Simple Blue is a free CSS template from www.templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
    <style type="text/css">
        .style2
        {
            width: 397px;
            border: 2px ridge #2A90C1;
            height: 101px;
        }
        </style>
        <script language="javascript" type="text/javascript">
     function accept(id)
   {
    location.href='completedfiles.aspx?id='+id;
    }
</script>
</head>
<body>
    <form id="form1" runat="server">
    <div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
    	<div id="site_title">
            <h1><a href="#">Welcome<span></span></a></h1>
        </div>
        
        <ul id="templatemo_menu">
            <li><a href="AdminHome.aspx" class="current"><span></span>Home</a></li>
            <li><a href="Viewemployee.aspx"><span></span>Employee</a></li>
			<li><a href="adddailyworkfile.aspx"><span></span>Send File</a></li>    
			<li><a href="completedfiles.aspx"><span></span>Completed</a></li>    
            <li><a href="Viewdevicedetails.aspx"><span></span>Device Details</a></li>  
            <li><a href="Default.aspx"><span></span>Logout</a></li>  
        </ul>
        
        <div id="search_box">
       </div>
	</div> <!-- end of templatemo_site_title_bar -->        
       
</div> <!-- end of templatemo_site_title_bar_wrapper -->

<%--<div id="templatemo_banner_wrapper_outter">
<div id="templatemo_banner_wrapper">
	
    <div id="templatemo_banner">
    
    <div id="templatemo_banner_slider">
    <!-- start of the slider -->
    
    <div id="one" class="contentslider">
            <div class="cs_wrapper">
                <div class="cs_slider">
                
                    <div class="cs_article">
                        <div class="cs_article_inner">
                             <div class="img_frame"><img src="images2.jpg" alt="Image Title 1" /></div>
                              <h2>Welcome</h2>
                              <p>Automatic System Logged At File Hacking Alert System</p>
                          
                        </div>                               
                    </div><!-- End cs_article -->
                    
                    <div class="cs_article">
                        <div class="cs_article_inner">
                            <div class="img_frame"><img src="images1.png" alt="Image Title 2" /></div>
                            <h2>Welcome</h2>
                            <p>Automatic System Logged At File Hacking Alert System</p>
                         
                        
                        </div>
                    </div><!-- End cs_article -->
                    
                    
                    
                </div><!-- End cs_slider -->
            </div><!-- End cs_wrapper -->
        </div><!-- End contentslider -->
        --%>
        <!-- Site JavaScript -->
        <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
        <script type="text/javascript">
            $(function() {
            $('#one').ContentSlider({
            width : '960px',
            height : '250px',
          	speed : 400,
            easing : 'easeOutSine'
            });
            });
        </script>
        <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
        <script src="js/chili/recipes.js" type="text/javascript"></script>
        <div class="cleaner">
    
    	<div class="cleaner"></div>
        </div>
  
  		<!-- end of the slider -->  
  
    
   	  </div> <!-- end of templatemo_popular_posts -->
    
    </div> <!-- end of templatemo_banner -->

</div> <!-- end of templatemo_banner_wrapper -->
</div> <!-- end of templatemo_banner_wrapper_outter -->

<div id="templatemo_content">
	
    <div id="twitter_section">
    	
        <p><span lang="en-us">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Work Finished File Details</span></p>
     
    </div>
    
  
    <div class="cleaner_h60" align="justify">
 <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
       PageSize="3" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
            Height="198px" Font-Bold="True"  HorizontalAlign="Center" 
       CellPadding="4" CssClass="style3" ForeColor="#333333" GridLines="None">
            <RowStyle HorizontalAlign="Center" BackColor="#EFF3FB"/>
                <Columns>
                   <asp:BoundField DataField="id" HeaderText="Id" />
                   <asp:BoundField DataField="foldername" HeaderText="Folder Name" />
                   <asp:BoundField DataField="filename" HeaderText="File Name"/>
                   <asp:BoundField DataField="filepath" HeaderText="File Path"/>
                   <asp:BoundField DataField="fileext" HeaderText="File Extension"/>
                   <asp:BoundField DataField="filesize" HeaderText="File Size"/>
                      <asp:BoundField DataField="workdate" HeaderText="Date"/>
                 <asp:BoundField DataField="status" HeaderText="Status"/>
                  <asp:BoundField DataField="empname" HeaderText="Employee Name"/>
                  <asp:TemplateField HeaderText="">
                 <ItemTemplate>
                    <a href="javascript:accept('<%# DataBinder.Eval(Container.DataItem,  "id")%>')" >Download</a>
                      </ItemTemplate>
             </asp:TemplateField>
              
               </Columns>
            <FooterStyle BackColor="#507CD1" ForeColor="White" Font-Bold="True" />
            <PagerStyle ForeColor="White" HorizontalAlign="Center" BackColor="#2461BF" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <EditRowStyle BackColor="#2461BF" />
            <AlternatingRowStyle BackColor="White" />
 </asp:GridView>   
  
  </div>
    
    
</div> <!-- end of templatemo_content -->
 
<br />

<br />

<br />
<br />
<br />

<br />

<br />
<br />
<div id="templatemo_footer_wrapper">
<div id="templatemo_footer">

   
    <center>
        Copyright <a href="#">All Rights Reserved</a> 
       </center>
    

</div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->

    </form>
</body>
</html>
